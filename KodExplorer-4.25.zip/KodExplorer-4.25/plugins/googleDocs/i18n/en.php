<?php
return array(
	"googleDocs.meta.name"				=> "Google Docs View",
	"googleDocs.meta.title"				=> "Google Docs View",
	"googleDocs.meta.desc"				=> "Google Docs is an online office software that includes online documents, forms, and presentations; third-party document previews can be provided by passing in a file address.
<br/><br/><b> Description: </b>, <br/>the address of the preview server must have the office where the server can access kod (the kod server must be outside the network)",
);
